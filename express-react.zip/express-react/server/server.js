const express = require("express");
const mongoose = require("mongoose");
const Document = require("./models/Document");
const app = express();

const uri = "mongodb+srv://RATCHAW:waahasan@cluster0.3xpf1ys.mongodb.net/?retryWrites=true&w=majority";

app.use(express.json());


// saving new form data to the database
app.post("/api/form", async (req, res) => {
  const { title, content } = req.body;
  try {
    const document = new Document({ title, content });
    await document.save();
    res.json(document);
    console.log("Save Success");
  } catch (error) {
    console.log(error);
  }
});

// getting all the forms from the database
app.get("/api/forms", async (req, res) => {
  try {
    const documents = await Document.find();
    res.json(documents);
  } catch (error) {
    console.log(error);
  }
});

// getting a single form from the database and deleting it
app.delete("/api/froms/:id", async (req, res) => {
  const id = req.params.id;
  try {
    await Document.findByIdAndDelete(id);
    res.json({ message: "Delete Success" });
  } catch (error) {
    console.log(error);
  }
});

async function connect() {
  try {
    await mongoose.connect(uri);
    console.log("Connect Success");
  } catch (error) {
    console.log(error);
  }
}

connect();

app.listen(5000, () => {
  console.log("Server running on port 5000");
});
