const mongoose = require("mongoose");

const NewdocformSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    maxlength: 100,
  },
  content: {
    type: String,
    required: true,
    maxlength: 1000,
  },
});

const Newdocform = mongoose.model("document", NewdocformSchema);

module.exports = Newdocform;
